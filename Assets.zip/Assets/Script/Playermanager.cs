using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Playermanager : MonoBehaviour
{
    public GameObject[] playerprefabs;
    int characterIndex;

    public void Awake()
    {
        characterIndex = PlayerPrefs.GetInt("SelectedCharacter", 0);
        Instantiate(playerprefabs[characterIndex], new Vector3(1.5f,0,0),Quaternion.identity);
    }
}
