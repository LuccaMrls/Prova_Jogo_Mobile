using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Timer : MonoBehaviour
{
    [SerializeField] TextMeshProUGUI tempo;
    private float tempo_atual;

    // Start is called before the first frame update
    void Start()
    {
        tempo_atual = 0;
    }

    // Update is called once per frame
    void Update()
    {
        tempo_atual += Time.deltaTime;
        tempo.text = tempo_atual.ToString("F0");
    }
}
